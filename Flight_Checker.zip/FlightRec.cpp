//
//  FlightRec.cpp
//  flights


#include <iostream>
using namespace std;
#include "Global.h"
#include "TimeRec.hpp"

class FlightRec {
private:
    
    string FlightNO;
    string Destination;
    TimeRec Time;
    FlightType FType;
    bool Delay;
    TimeRec ExpectedTime; // if the flight is delayed
    
public:
    
    /**
    A word about 'nested' constructors.  Object oriented languages tend to want the constructors
    inside of other constructors to be fired first before the constructor does anything else.  Fair
    enough, however while JAVA will allow the seemingly obvious idiom below:
     
    ExpectedTime = TimeRec (0,0,0);             // Some kind of default
    Time = TimeRec(h,m,s);                            // Constructor checks h,m & s
     
    In C++ this will result in incomprehensible compiler messages such as, "Constructor for 'FlightRec'
    must explicitly initialize the member which does not have a default constructor".
     
     You MUST use the remarkably obvious constructor initialization list, as show below.
     */
    
    // Necessary if just need a blank FlightRec
    FlightRec () : Time () , ExpectedTime () {
        FlightNO = EMPTY;
        Destination = EMPTY;
        FType = Arrival;
        Delay = false;
    }
    
    // Necessary to locate flights
    FlightRec (string FN) : Time () , ExpectedTime () {
#if defined(DEBUG) || defined(_DEBUG)       // Only used during development
        assert (!FN.empty());               // Sanity checking
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
        FlightNO = FN;
        Destination = EMPTY;
        FType = Arrival;
        Delay = false;
    }
    
    // These are the main constructors, one which has an ExpectedTime
    // and another which does NOT.  The boolean Delay variable is set
    // depending on whether ExpectTime is defaulted or not
    
    FlightRec (const string FN,const string D,const int h, const int m, const int s,
               const FlightType FT, const int eh, const int em, const int es)
                    : Time (h, m, s) , ExpectedTime (eh,em,es) {

#if defined(DEBUG) || defined(_DEBUG)   // Only used during development
        // Brain damaged compiler does not allow for NULL pointer check...
        assert (!FN.empty());                       // Sanity checking
        assert (!D.empty());
        assert (FT == Departure || FT == Arrival);  // Better be one of the two!
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
                        
        FlightNO = FN;
        Destination = D;
        FType = FT;
        Delay = true;                              // Set, since expected time supplied
    }
    
    FlightRec (const string FN,const string D,const int h, const int m, const int s,
               const FlightType FT) : Time (h, m, s) , ExpectedTime () {

#if defined(DEBUG) || defined(_DEBUG)               // Sanity check during development
        assert (!FN.empty());
        assert (!D.empty());
        assert (FT == Departure || FT == Arrival);
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
        
        FlightNO = FN;
        Destination = D;
        FType = FT;
        Delay = false;                              // No delay since no expected time
    }
    
    // Destructor
    ~FlightRec() {                                      // Don't leave dangling strings
        if (!FlightNO.empty()) FlightNO.erase();
        if (!Destination.empty()) Destination.erase();
    }

    // Accessors
    const FlightType getType() { return FType; }
    TimeRec getTime() { return (const TimeRec) Time; }
    const bool getDelay() { return Delay; }
    TimeRec getExpectedTime() {
        if (Delay) return ExpectedTime;
        else return TimeRec(0,0,0);
    }
    
    // Time Mutators
    void setTime (TimeRec &t) { Time = t; }         // Uses overloaded assignment!!

    void setDelay (TimeRec &t) {
        if (TimeRec(0,0,0) == t)                    // Clearing the delay?
             Delay = false;                         // Fine, get rid of it
        else Delay = true;                          // Otherwise, waiting around
        
        ExpectedTime = t;                           // Either way, copy over the time
    }
    
    // Assignment operator, object checked on creation
    void operator= (const FlightRec & o) {

        FlightNO = o.FlightNO;
        Destination = o.Destination;
        Time = o.Time;                              // TimeRec assignment checks arguments
        FType = o.FType;
        Delay = o.Delay;
        if (Delay) ExpectedTime = o.ExpectedTime;   // Ditto TimeRec assignment
    }

    // Flight sorting method; scrubs compare result to a simple trinary value
    
    const int flightCompare (const FlightRec & o) {
        const int r = this->FlightNO.compare(o.FlightNO);   // Compare the strings
        
        if (r < 0) return -1;               // Easier to switch() on
        else if (r > 0) return  1;
        else return 0;
    }
    
    // Various comparisons we might not use (not exhaustive)
    const bool operator== (const FlightRec & o) { if (this->flightCompare(o) == 0) return true; else return false; }
    const bool operator!= (const FlightRec & o) { if (this->flightCompare(o) != 0) return true; else return false; }
    const bool operator<  (const FlightRec & o) { if (this->flightCompare(o)  < 0) return true; else return false; }
    const bool operator>  (const FlightRec & o) { if (this->flightCompare(o)  > 0) return true; else return false; }
    
    // Functions to render the class to a stream
    
    // Functions to render the class to a stream
    friend std::ostream& operator<< (std::ostream& o, FlightRec f) {
        o << &f;        // Make into a pointer and hand off
        return o;
    }
    
    friend std::ostream& operator<< (std::ostream& o, FlightRec *f) {
        o << f->FlightNO << TAB << f->Destination << TAB << &f->Time << TAB;
        if (f->FType == Departure)    o << "Departure";
        else if (f->FType == Arrival) o << "Arrival  ";
        
        if (f->Delay)
            o << TAB << "Delayed" << TAB << &f->ExpectedTime;
        o << endl;              // Tie off this sillyness

        return o;
    }

    string toCSV() {                    // Helper for writing CSV files
        string s;                       // What we'll return
        
        if (FType == Departure)    s = "D,";
        else if (FType == Arrival) s = "A,";
        
        s += FlightNO;                  // Put in the flight (which is a string
        s += ",";                       // The seperator
        s += Destination;               // Flight destination
        s += ",";                       // The seperator
        s += Time.toString();           // Render the time
        
        if (!Delay) return s;           // If not delated, we're done
        
        s += ",";                       // Another seperator
        s += ExpectedTime.toString();   // Render the expected time
        return s;                       // Return longer string
    }
    
#if defined(DEBUG) || defined(_DEBUG)   // Only used during development
    /* Internal Test; should give:
     
     F1, BA221    LONDON     6:0:0    Departure
     F2, OA234    ATHENS    12:0:0    Departure    Delayed    13:15:15
     F1 is earlier than F2
     F1 Flight Number sorts before F2
     
     */
    
    static void InternalTest () {
        
        FlightRec f1 = FlightRec ("BA221","LONDON",06,00,00,Departure);
        FlightRec f2 = FlightRec ("OA234","ATHENS",12,00,00,Departure,13,15,00);

        cout << "F1, " << f1;
        cout << "F2, " << f2;

             if (f1 == f2) cout << "They are the same" << endl;
        else if (f1 >  f2) cout << "F1 is later than F2" << endl;
        else if (f1 <  f2) cout << "F1 is earlier than F2" << endl;
        
        switch (f1.flightCompare(f2)) {
            case -1:
                cout << "F1 Flight Number sorts before F2" << endl;
                break;
                
        case 0:
                cout << "F1 and F2 have the same Flight Number" << endl;
                break;
                
        case 1:
                cout << "F1 Flight Number sorts after F2" << endl;
                break;
                
        default:            // String compare only gives three values...
                abort();    // But didn't...
                break;
        } // End of switch
    } // End of Internal Test
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
}; // End of FlightRec

