//
//  Node.hpp
//  flights


#ifndef Node_hpp
#define Node_hpp

#include "Global.h"

#if defined(TEMPLATES)
#include "Node.cpp"
#else
template <class K> struct Node {
public:
    K entry;
    Node<K> *next;
    
    Node <K> ();
};
#endif // TEMPLATES
#endif /* Node_hpp */
