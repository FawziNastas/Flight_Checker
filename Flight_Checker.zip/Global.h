//
//  Global.h
//  flights


#ifndef Global_h
#define Global_h

// Items that MUST have global visibility
enum FlightType { Departure, Arrival };
const char TAB[] = { '\t', '\0' };  // To fool std::
const char EMPTY[] = { '\0' };      // So strings don't break

// Note use of inclusion of SOURCE CODE.  Templates will
// BREAK without actually seeing the code for the class
// because they won't know what to fill in.

#define TEMPLATES

#endif /* Global_h */
