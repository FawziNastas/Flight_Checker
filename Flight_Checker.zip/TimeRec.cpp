//  TimeRec.cpp
//  flights
// TimeRec is a TimeRecord; it keeps time as seperate digits and
// implements comparision and clock arithmatic

#include <iostream>
using namespace std;
#include <string>
#include <assert.h>
#include "Global.h"

class TimeRec {
private:
    int hour;   //0 to 23
    int min;    //0 to 59
    int sec;    //0 to 59

    // Use of const variables is for debugging

    const int magnitude() {             // Converts values to comparable form
        const int hs = hour*60*60;      // Converts hours to seconds
        const int ms = min*60;          // Convert minutes to seconds
        const int ts = hs+ms+sec;       // Total secomds
        
        return ts;
    }

public:

    // Constructors do not modify calling arguments

    TimeRec () {                        // USed to default everything
        hour = 0;
        min = 0;
        sec = 0;
    }
    
    // Arguments specified as seperate integers

    TimeRec (const int h, const int m, const int s) {

#if defined(DEBUG) || defined(_DEBUG)   // Only used during development
        assert (h > -1 && h < 24);      // Sensible hour?
        assert (m > -1 && h < 60);      //  and minute?
        assert (h > -1 && h < 60);      //  and second?
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

        hour = h;                       // Finally assign everything
        min = m;
        sec = s;
    }

    // Converts a total of seconds into hours, minutes and seconds
    TimeRec (const int ts) {

#if defined(DEBUG) || defined(_DEBUG)   // Only used during development
        assert(ts>-1);                  // Don't allow nonsense
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

        const int nh = ts / (60*60);    // Extract hours
        const int h = nh % 24;          // Clock, day arithmatic
        const int ns = ts % (60*60);    // Remove from running total
        const int m = ns / 60;          // Gets the minutes
        const int s = ns % 60;          // Gets the seconds
        
#if defined(DEBUG) || defined(_DEBUG)   // Only used during development
        assert (h > -1 && h < 24);      // Sensible hour?
        assert (m > -1 && h < 60);      //  and minute?
        assert (h > -1 && h < 60);      //  and second?
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
        
        hour = h;                       // Finally assign everything
        min = m;
        sec = s;
    }

    // Assignment operator; mainly used to double check for junk
    void operator= (const TimeRec & o) {

#if defined(DEBUG) || defined(_DEBUG)   // Only used during development
        assert (o.hour > -1 && o.hour < 24);        // Sensible hour?
        assert (o.min  > -1 && o.min  < 60);        //  and minute?
        assert (o.sec  > -1 && o.sec  < 60);        //  and second?
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

        hour = o.hour;                              // Passed, allow assignment
        min  = o.min;
        sec  = o.sec;
    }

    // Clock arithmatic.  Basically gives a circular timeline going around 24
    // It doesn't really make any sense to multiply and divide time, does it?
    // These are not used, but were implemented in order to debug the class

    const TimeRec operator+ (TimeRec &o) {
        const int ts = this->magnitude();           // Our total seconds
        const int os = o.magnitude();               // Other's total
        const int tb = ts + os;                     // Total of both
        const TimeRec r = TimeRec (tb);             // Use a different constructor
                                                    // Which splits total
        return r;                                   // Return final results
    }

    TimeRec operator+= (TimeRec o) {
        const int ts = this->magnitude();           // Our total seconds
        const int os = o.magnitude();               // Other's total
        const int tb = ts + os;                     // Total of both
        TimeRec r = TimeRec (tb);                   // Use a different constructor
                                                    // Which splits total
        return r;
    }
    
    // Subtraction is NOT communitive!
    const TimeRec operator- (TimeRec &o) {
        const int ts = this->magnitude();           // Our total seconds
        const int os = o.magnitude();               // Other's total
        const int tb = ts - os;                     // difference of the two

        if (tb < 0 ) {                              // Fix up if negative
            TimeRec n = TimeRec ((24*60*60) + tb);  // Turns clock counter-clockwise
            return n;
        } else {                                    // Otherwise, if positive, just use it
            TimeRec r = TimeRec (tb);               // Split total into parts
            return r;
        }
    }
    
    // Various comparisons we might not use (not exhaustive)
    const bool operator== (TimeRec & o) { return this->magnitude() == o.magnitude(); }
    const bool operator!= (TimeRec & o) { return this->magnitude() != o.magnitude(); }
    const bool operator<  (TimeRec & o) { return this->magnitude() <  o.magnitude(); }
    const bool operator>  (TimeRec & o) { return this->magnitude() >  o.magnitude(); }
    
    // Functions to render the class to a stream
    
    friend std::ostream& operator<< (std::ostream& o, TimeRec t) {
        o << &t;                        // Just build a pointer and hand the off
        return o;
    }

    // Columnar output
    friend std::ostream& operator<< (std::ostream& o, TimeRec *t) {
        o << t->toString(t);            // Build the string
        return o;                       // Return it
    }

    string toString() { return toString(this); };
    
    string toString(TimeRec *t) {       // Helper for writing CSV files
        string s;                       // Place to build a string
        
        if (t->hour < 12)
            s = " " + to_string(t->hour);
        else s = to_string(t->hour);
        s += ":";
        if (t->min < 10)
            s += "0" + to_string(t->min);
        else s += to_string(t->min);
        s += ":";
       if (t->sec <10)
           s += "0" + to_string(t->sec);
        else s += to_string(t->sec);
        return s;
    }
    
#if defined(DEBUG) || defined(_DEBUG)   // Only used during development
    /* Internal Test; should give:
     T1, 11:0:0
     T2, 6:21:21
     T3, 17:21:21
     T1 is later than T2
     Total is, 17:21:21
     Difference is, 4:38:38
     Other way, 19:21:21
     */

    static void InternalTest () {
        TimeRec t1 = TimeRec (11,00,21);
        TimeRec t2 = TimeRec (6,21,33);
        TimeRec t3 = t1 + t2;

        cout << "T1, " << t1 << endl;
        cout << "T2, " << t2 << endl;
        cout << "T3, " << t3 << endl;

             if (t1 == t2) cout << "They are the same" << endl;
        else if (t1 >  t2) cout << "T1 is later than T2" << endl;
        else if (t1 <  t2) cout << "T1 is earlier than T2" << endl;

        cout << "Total is, " << (t1 + t2) << endl;
        cout << "Difference is, " << (t1 - t2) << endl;
        cout << "Other way, " << (t2 - t1) << endl;
 
    }
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

};  // End of TimeRec class

