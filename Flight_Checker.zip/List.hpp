//
//  List.hpp
//  flights


#ifndef List_hpp
#define List_hpp

#include <iostream>
using namespace std;
#include "Global.h"

#if defined(TEMPLATES)
#include "List.cpp"
#else
#include "Node.hpp"
template <class T> class List {
public:
    
    // Constructors
    List ();
    List (const T E);
    List (const Node<T> &);

    // Accessors to return number of nodes in list (like length of string)
    const int size();
    const int length();
    const bool empty();
    const bool isEmpty();

    // List operations
    bool fetch(T *E)
    T fetchN();
    bool remove (T E);
    void add (T *E);
    
    // Method to render the class to a stream
    friend std::ostream& operator<< (std::ostream&,  List<T> *);
}; // End of List Class
#endif // Templates

#endif /* List_hpp */
