//
//  List.cpp
//  flights

/** The large use of const is for maximum compiler checking */

#include <iostream>
using namespace std;
#include <assert.h>

#include "Global.h"
#include "Node.hpp"

template <class T> class List {
private:
    int count;                          // Nodes in this list
    Node<T> *head;                      // Pointer to nodes
    Node <T> *EOL = (Node <T> *) 0;     // Used for initialization and checking
    
public:
    /** Various constructors */
    
    List () {                           // Empty constructor
        head = EOL;                     // Not pointing anywhere
        count = 0;                      // Nothing in here!
    }
    
    List (const T E) {                  // If building with a templated object
        head = new Node <T> ();         // Allocate a node
        head->entry = E;                // Assign item
        count = 1;                      // Have one item!
    }
    
    List (const Node<T> & N) {          // If building from Templated node

#if defined(DEBUG) || defined(_DEBUG)   // Sanity check during development
        assert (N != EOL);              // Have to get passed a node
        assert (N.next == EOL);         // But not a list of nodes!!
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

        head->entry = N.entry;          // Copy over the entry
        head->next  = N.next;           // This is the head of the list
        count = 1;                      // One item in there now!!
    }
    
    // Accessors to return number of nodes in list (like length of string)
    const int size()     { return count; }
    const int length()   { return count; }
    const bool empty()   { return count == 0; }
    const bool isEmpty() { return count == 0; }
    
    // Looks for an entry and returns it, if found
    
    bool fetch(T *E) {
        if (count == 0) return false;       // Nothing there, anyhow?
        if (count == 1) {                   // One member is easy!
            if (*E == head->entry) {        // Is it this head??
                *E = head->entry;           // Yep, return it
                return true;                // We found it!
            } else return false;            // Otherwise, wasn't there
        }
        
        /* Otherwise, have to go looking */
        
        int i = count;                      // Typical loop variable
        Node<T> *n = head;                  // Initialize to start of list
#if defined(DEBUG) || defined(_DEBUG)       // Sanity check during development
        assert (n != EOL);                  // Have to have at least one node in there!
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

        while (i--) if (*E == n->entry) {   // Loop through whole list
            *E = n->entry;                  // Found it!  Return it
            return true;                    // Tell us the good news
        } else {                            // Otherwise, not this one
                n = n->next;                // Step to next
                if (n == EOL) break;        // If hit end of list, done searching
        }                                   // End of while

#if defined(DEBUG) || defined(_DEBUG)       // List consistency check
        if (0 == i) assert (n == EOL);      // Count is zero, better be at end of list!
        if (n == EOL) assert (0 == i);      // If count is zero, better be at end of list!
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

        return false;                       // Return false if never found it
    }
    
    // Fetches N'th item in a list (ZERO BASED!!)
    T fetchN(int N) {
        if (count == 0)                     // Anything there, anyway?
            return (T) 0;                   // No, so don't return anything
        if ((N < 0) || (N > count-1))       // Out of range?
            return (T) 0;                   // Will never return anything
        if (N == 0)                         // First thing?
            return (T) head->entry;         // That would be the head of the list
        
        int i = N;                          // Typical loop variable
        Node<T> *n = head;                  // Initialize to start of list
        
        while (i--) {                       // Step to the node
            if (n == EOL)                   // Fell off the list??
                return (T) 0;               // Oh well...
            n = n->next;                    // Step to next node
        }
        
#if defined(DEBUG) || defined(_DEBUG)       // List consistency check
        assert (n != EOL);                  // Better not have fallen off the end of the list!
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
        
        return (T) n->entry;                // Return the entry
    }
    
    // Removes a particular node from a list, based on the operation
    // of the templates implementation of the equality function
    // Returns true if item was found and removed
    
    bool remove (T E) {                     // Loops through list until find entry
        /** First, handle some edge cases zero nodes and a single node */
        
        if (count == 0) return false;       // Empty list means nothing to do!

        if (count == 1) {                   // One member is easy!
            if (E == head->entry) {         // Is it this head??
                delete head;                // Punt the remainder of list
                head = EOL;                 // Tie list off
                count = 0;                  // Nothing left
                return true;                // We ditched it!
            } else return false;            // Otherwise, wasn't there
        }

        int i = count;                      // Typical loop variable
        Node <T> *p = EOL;                  // Previous pointer
        Node<T> *n = head;                  // Initialize to start of list
#if defined(DEBUG) || defined(_DEBUG)       // Sanity check during development
        assert (n != EOL);                  // Have to have at least one node in there!
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

        while (i--) if (E == n->entry) {    // Loop through whole list
            if (p == EOL) {                 // Was first entry in list?
                delete head;                // Delete old head
                head = n->next;             // Head points to this node's next
            } else {                        // Otherwise, in the interior
                delete p->next;             // Delete previous
                p->next = n->next;          // And snip remains out
            }                               // End case interior node
            count--;                        // Either way, one less node in the list
            return true;                    // And whacked it!!
        } else {                            // Otherwise, haven't found it yet
            p = n;                          // Current is now previous
            n = n->next;                    // Step to next
            if (n == EOL) break;            // If hit end of list, done searching
        }
#if defined(DEBUG) || defined(_DEBUG)       // List consistency check
        if (0 == i) assert (n == EOL);      // Count is zero, better be at end of list!
        if (n == EOL) assert (0 == i);      // If count is zero, better be at end of list!
        assert (p != EOL);                  // Should have been caught by previous edge case
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

        return false;                       // Return false if never found it
    } // End of remove method

    // Adds a node to the list;
    // Note: the list is always kept sorted on insert!!
    
    void add (T & E) {                      // Loops through list until find entry
        /** First, handle some edge cases: zero nodes and a single node */
        
        if (count == 0) {                   // Nothing in there?
            head = new Node <T> ();         // Allocate a node
            head->entry = E;                // Assign item
            count = 1;                      // Now have a node in there!
            return;                         // And done
        }
        
        Node<T> *N = new Node <T> ();       // Get a node to insert
        N->entry = E;                       // Copy in the entry
        N->next = EOL;                      // doesn't point anywhere (yet)

        if (count == 1) {                   // Another trivial edge case
#if defined(DEBUG) || defined(_DEBUG)       // Sanity check during development
            assert (head != EOL);           // Better be a head!
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
            if (E < head->entry) {          // Before current (head)?
                N->next = head;             // Goes in front of the head
                head = N;                   // This is the new head
            } else head->next = N;          // Otherwise, it's after the head
            count++;                        // Either way, count an insertion
            return;                         // And done
        }

        // OK, now the general case: scan the list
        Node<T> *n = head;                  // Initialize to start of list
        
    #if defined(DEBUG) || defined(_DEBUG)
        assert (n != EOL);                  // Have to have at least one node in there!
    #endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

        // BUT!!  Are we going in at the beginning?
        if (E < head->entry) {              // Before current (head)?
            N->next = head;                 // Goes in front of the head
            head = N;                       // This is the new head
            count++;                        // And count an insertion
            return;                         // And done
        }
        
        // No more edge cases, do general scan
        Node <T> *p = EOL;                  // Previous node
        int i;                              // Typical loop counter
        
        for (i=count;0<i;i--) {             // Loop through the list
            if (n == EOL)                   // Hit the end of list??
                break;                      // Yeah, get out here
            if (E < n->entry)               // Greater than next?
                break;                      // Yep, time to LEAVE
            p = n;                          // Previous is old current
            n = n->next;                    // New current is next
        }
                                            // Fell out, see where node goes
#if defined(DEBUG) || defined(_DEBUG)       // List consistency check
        if (0 == i) assert (n == EOL);      // Count is zero, better be at end of list!
        if (n == EOL) assert (0 == i);      // If count is zero, better be at end of list!
        assert (p != EOL);                  // Should have been caught by previous edge case
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

        p->next = N;                        // Always previous
        if (n != EOL)                       // Not at end of list?
            N->next = n;                    // No, our next points to rest of list
        count++;                            // Either way, count an insertion
        return;                             // We're finally done with the add
    } // End of add method
    
    // Function to render the class to a stream
    // Friend class can't use EOL... Why?
    
    friend std::ostream& operator<< (std::ostream& o,  List<T> *L) {
    
        int i = L->count;                   // Typical loop variable
        Node <T> *l = L->head;              // Pointer to list

#if defined(DEBUG) || defined(_DEBUG)       // List consistency check
        if (0 == i) assert (l == (Node<T> *) 0); // Count is zero, better be at end of list
        if (l == (Node<T> *) 0) assert (0 == i); // If count is zero, better be at end of list!
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
        
        if (0 == i) {                       // Nothing there?  That's easy!
            o << "[EMPTY]" << endl;
            return o;
        }

        while (i--) {                       // Don't use EOL, just use counter
            o << &l->entry;                 // Ask object to render itself
            l = l->next;                    // NEXT!! (object)
        }
#if defined(DEBUG) || defined(_DEBUG)       // List consistency check
        assert (l == (Node<T> *) 0);        // Count is zero, so better be at end of list
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

        return o;                           // Return final output stream
    }
}; // End of List Class
