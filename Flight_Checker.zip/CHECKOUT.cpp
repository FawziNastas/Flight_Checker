//
//  CHECKOUT.cpp
//  flights


#if defined(DEBUG) || defined(_DEBUG)   // Only when doing internal checking
#include <iostream>
using namespace std;

#include "Global.h"                     // Stuff everybody needs to know

#include "TimeRec.hpp"
#include "FlightRec.hpp"
#include "Node.hpp"
#include "List.hpp"

void Testing(List<FlightRec> *f) {
    // Do NOT use leading zeros as Xcode will think these are octal constants!
    FlightRec f1 = FlightRec ("BA221","LONDON", 6, 0, 0,Departure);
    FlightRec f2 = FlightRec ("CY333","LONDON", 9, 0, 0,Departure);
    FlightRec f3 = FlightRec ("OA234","ATHENS",12, 0, 0,Departure,13,15, 0);
    
    FlightRec f4 = FlightRec ("CY332","LONDON", 2,16, 0,Arrival);
    FlightRec f5 = FlightRec ("BA222","LONDON", 2,45, 0,Arrival, 4,30, 0);
    FlightRec f6 = FlightRec ("IT312","ROME",   5, 0, 0,Arrival);
    FlightRec f7 = FlightRec ("CY231","ATHENS", 5, 0, 0,Arrival);
    
    cout << endl << "**** Testing Sorted Insertions ****" << endl << endl;
    
    f->add(f1);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    f->add(f2);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    f->add(f3);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    f->add(f4);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    f->add(f5);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    f->add(f6);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    f->add(f7);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    cout << endl << "**** Testing Remove ****" << endl << endl;
    
    cout << "Removing " << &f1;
    f->remove(f1);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    cout << "Removing " << &f2;
    f->remove(f2);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    cout << "Removing " << &f3;
    f->remove(f3);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    cout << "Removing " << &f4;
    f->remove(f4);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    cout << "Removing " << &f5;
    f->remove(f5);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    cout << "Removing " << &f6;
    f->remove(f6);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    cout << "Removing " << &f7;
    f->remove(f7);
    cout << "Items: " << f->length() << endl;
    cout << f << endl;
    
    return;     // Completed basic testing
}


void CHECKOUT() {
    TimeRec::InternalTest();        // Time Record internal testing
    cout << endl;
    FlightRec::InternalTest();      // Flight Record internal testing
    
    List<FlightRec> *f = new List <FlightRec> ();  // Set up an empty list
    
    Testing(f);                     // Do some testing
    delete f;                       // Punt the list
    
    return;                         // Just blabs, returns NOTHING
}
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

