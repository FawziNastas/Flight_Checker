//
//  Auxiliary.hpp
//  flights


#ifndef Auxiliary_hpp
#define Auxiliary_hpp

// Functions called from the main() command loop

bool setCurrentTime(TimeRec &);                 // Support for command 'a'
bool readFile(List<FlightRec> *);               // Support for command 'b'
bool writeFile(List<FlightRec> *);              // Support for command 'c'
bool addFlight(List<FlightRec> *);              // Support for command 'd'
bool cancelFlight(List<FlightRec> *);           // Support for command 'e'
bool modifyFlightTime(List<FlightRec> *);       // Support for command 'f'
bool delayFlight(List<FlightRec> *);            // Support for command 'g'
bool notDeparted(List<FlightRec> *,TimeRec &);  // Support for command 'i'
bool notArrived(List<FlightRec> *,TimeRec &);   // Support for command 'j'
bool sortTime(List<FlightRec> *);               // Support for command 'l'
bool displayFlight(List<FlightRec> *);          // Support for command 'm'

#endif /* Auxiliary_hpp */
