//
//  Auxiliary.cpp
//  flights


#include <iostream>
using namespace std;

#include <fstream>                      // Need all this fine stuff to parse a file
#include <sstream>

#include "Global.h"                     // Useful symbol definitions
#include "TimeRec.hpp"
#include "FlightRec.hpp"
#include "Node.hpp"
#include "List.hpp"

/** Utility routines only used in this module (not e use of static outside of class!! */

// Parser to just grab some time
static bool ParseTime(int& h, int& m, int& s) {
    string t;                           // Line of text
    size_t l;                           // Length of line of text
    size_t ci;                          // Colon indices

    cout << "Enter Time: " << flush;    // Prompt
    if (!getline(cin, t)) {              // Get a line of text
        cerr << "Could not read the the time" << endl;
        return false;                   // Return failure
    }

    if (t.empty()) return false;        // Get out of here if typed nothing
    l = t.length();                     // Otherwise get the length

    ci = t.find(':');                   // Look for the colon
    if (ci == std::string::npos)        // Didn't find it??
        return false;                   // Not anybody's idea of time

    h = 0;                              // Non-explosive
    m = 0;                              //    Default
    s = 0;                              //        Values

    t[ci] = '\0';                       // Let's drop a null in there and tie off the hour
    h = stoi(t);                        // Grab the hour

    t.erase(0, ci + 1);                 // Whack what we swallowed for the hour
    ci = t.find(':');                   // Look for next colon
    if (ci == std::string::npos) {      // Didn't find it??
        m = stoi(t);                    // Convert minutes
        return true;                    // We're fine
    }

    t[ci] = '\0';                       // Let's drop a null in there and tie off the hour
    m = stoi(t);                        // Grab the minute

    t.erase(0, ci + 1);                 // Whack what we swallowed for the minute
    s = stoi(t);                        // Grab the second
    return true;                        // Done
}

// Note: MUST: process a pointer, otherwise a copy of the string is made!

static void UpperCase(string* s) {     // Used to uppercase a string

#if defined(DEBUG) || defined(_DEBUG)
    assert(s != (string*)0);
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

    if (s->empty())                     // Don't do anything if nothing to do
        return;                         // Beat it!

    volatile size_t i = s->size();      // Typical loop variable

    while (0 < i--) {                   // Wants this in braces...
        s->at(i) = toupper(s->at(i));
    }
}

/* Parses a file in our interal format.  File looks like

    D,BA221,LONDON,06:00
    D,CY333,LONDON,09:20
    D,OA234,ATHENS,12:00,13:15
    A,CY332,LONDON,02:16
    A,BA222,LONDON,02:45,04:30
    A,IT312,ROME,05:00
    A,CY231,ATHENS,05:20

    'D' means Departure, 'A' means Arrival.  Anything else is an error
 */

static bool parseCSVfile(List<FlightRec>* f, string file) {
    string line;                    // Line of text from the file

    string FN;                      // Used to build a FlightRec
    string D;
    int h, m;
    int eh, em;
    FlightType FT;

    string t;                       // Temporary string
    char c;                         // Temporary character
    size_t ci;                      // Comma index (if seen)

    if (file.empty()) {             // Some kind of nonsense?
        cerr << "Can not open a blank file name" << endl;
        return false;
    }

    ifstream inFile(file);          // First, try to open it
    if (!inFile.is_open()) {        // Did this work??
        cerr << "Failed to open file: " << file << endl;
        return false;               // Kick the failure up
    }

    while (getline(inFile, line)) { // Loop getting lines until end of file hit
        stringstream ss(line);      // Treat the line of text as a stream (like from a terminal)

        getline(ss, t, ',');        // Get flight type character
        c = t[0];                   // Get the character
        if (c == 'A') FT = Arrival;
        else if (c == 'D') FT = Departure;
        else {
            cerr << "Incorrect flight type: " << t << endl;
            return false;       // Might as well stop right now
        }

        getline(ss, FN, ',');       // Get the flight number and destination
        getline(ss, D, ',');

        getline(ss, t, ':');        // Get hours
        h = stoi(t);                // Convert it to an integer (hopefully..)
        getline(ss, t);             // Get minute (and maybe more)
        ci = t.find(',');           // Look for the comma
        if (ci == std::string::npos) { //Didn't find it?
            m = stoi(t);            // Safe to parse the minute!
            FlightRec* fr =         // Create a flight record object!
                new FlightRec(FN, D, h, m, 0, FT);
#if defined(DEBUG) || defined(_DEBUG)
            cout << fr;             // Let's see what we got!!
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
            f->add(*fr);            // Link it in
            continue;               // Next line
        }
        // Otherwise, have to do a little fooling around
        t[ci] = '\0';               // Let's drop a null in there and tie off the minute
        m = stoi(t);                // Grab the minute
        stringstream es(&t[ci + 1]); // Now set our string stream to the end

        getline(es, t, ':');        // Get hours
        eh = stoi(t);               // Convert it to an integer (hopefully..)
        getline(es, t);             // Get minute
        em = stoi(t);               // Convert it to an integer (hopefully..)

        FlightRec* fr =             // Create a delated flight record object!
            new FlightRec(FN, D, h, m, 0, FT, eh, em, 0);
#if defined(DEBUG) || defined(_DEBUG)
        cout << fr;                 // Let's see what we got!!

#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
        f->add(*fr);                // Link it in
        continue;                   // Next line
    } // End of while loop

    if (inFile.is_open())           // Done reading; file open?
        inFile.close();             // Yep, close it

    return true;                    // Done reading the file
}

// Writes a file given a list of flights and a name to write them in.
// Note: catching an exception is definitive on Mac OS X.  The file
//  is open, yet the is_open() returns FALSE!!

static bool writeCSVfile(List<FlightRec>* f, string file) {
    if (file.empty()) {             // Some kind of nonsense?
        cerr << "Can not open a blank file name" << endl;
        return false;
    }

    int n = f->length();                // Get the number of flights
    if (0 == n) return false;           // Anything in there?  We don't write empty files

    auto outFile = ofstream{};          // Our output file stream
    errno = 0;                          // Reset error

    try {                               // Set up for exceptions on open
        outFile.exceptions(std::ios::badbit | std::ios::failbit);
        outFile.open(file);
    }
    catch (std::exception& e) {         // Threw an error; blat about it
#if defined(_WIN64) || (_WIN32)
        char error_text[100];           // Stop Visual Studio blat...
        strerror_s(error_text, 100, errno);

        std::cerr << "failure.\n  what(): "
                << e.what() << "\n  errno : "
                << error_text << endl;
#else
        std::cerr << "failure.\n  what(): "
            << e.what() << "\n  errno : "
            << strerror(errno) << endl;
#endif
        return false;                  // Get out here
    }

    for (int i = 0; i < n; i++) {
        FlightRec fr = f->fetchN(i);    // Get flight record at slot i
        outFile << fr.toCSV() + "\n";   // Write it to the file!!!
    }

    outFile.close();                    // Error checking?
    return true;                        // Finally done
}

/** Specific support for commands */

// support for command 'a'

bool setCurrentTime(TimeRec& TIME) {
    cout << "Set the current time" << endl;
    int h, m, s;                  // Hours, minutes, seconds

    if (!ParseTime(h, m, s)) {
        cerr << "Could not parse the current time" << endl;
        return false;
    }

    TimeRec t = TimeRec(h, m, s); // Build the time record
    if (TimeRec(0, 0, 0) == t)
        cout << "Clearing current time" << endl;
    else cout << "Setting current time to " << t << endl;

    TIME = t;                   // Use overloaded equals operator
    return true;                // Worked!
}

// Support for command 'b'

bool readFile(List<FlightRec>* f) {
    string line;                // file name we'll try to read

    cout << "Enter the file name to read: " << flush;
    if (!getline(cin, line)) {   // Get a line of text
        cerr << "Could not read the file name" << endl;
        return false;
    }

    if (parseCSVfile(f, line)) {
        cout << "Completed read in of file: " << line << endl;
        return true;
    }
    else {
        cerr << "Failed to process file: " << line << endl;
        return false;
    }
}

// Support for command 'c'

bool writeFile(List<FlightRec>* f) {
    string line;

    int n = f->length();                        // Get the number of flights
    if (0 == n) {                               // Anything in there, actually?
        cerr << "No flights entered" << endl;   // Nope, so nothing to do
        return false;
    }

    cout << "Enter the file name to write: " << flush;
    if (!getline(cin, line)) { // Get a line of text
        cerr << "Could not read the file name" << endl;
        return false;
    }

    if (writeCSVfile(f, line)) {
        cout << "Completed; Flight Records written: " << n << endl;
        return true;
    }
    else {
        cerr << "Failed to write file: " << line << endl;
        return false;
    }
}

// Support for command 'd'

bool addFlight(List<FlightRec>* f) {
    string line;

    cout << "Enter flight number to add: " << flush;
    if (!getline(cin, line)) {                       // Get a line of text
        cerr << "Could not read flight number" << endl;
        return false;
    }
    else UpperCase(&line);                          // All flights are UPPER case
    const string FN = line;                         // Assign to be passed in

    cout << "Enter Destination: " << flush;         // Prompt for file name
    if (!getline(cin, line)) {                      // Get a line of text
        cerr << "Could not read flight number" << endl;
        return false;
    }
    else UpperCase(&line);                          // All flights are UPPER case
    const string D = line;                          // Assign to be passed in

    cout << "Arrival or Departure: " << flush;      // Ask whether delayed
    if (!getline(cin, line)) {                      // Get a line of text
        cerr << "Could not read flight number" << endl;
        return false;
    }
    else UpperCase(&line);                          // All flights are UPPER case

    FlightType pFT;                                 // Parsed file type (not const)
    if ('A' == line.at(0))                          // Arrival?
        pFT = Arrival;                              // Set
    else if ('D' == line.at(0))                     // Departure
        pFT = Departure;                            // Set
    else {                                          // Neither??
        cerr << "'" << line << "' is neither [A]rrival or [D]eparture" << endl;
        return false;
    }
    const FlightType FT = pFT;                      // Make constant

    int h, m, s;                                    // Hours, minutes, seconds
    if (!ParseTime(h, m, s)) {                      // Try for flight time
        cerr << "Could not parse flight time" << endl;
        return false;
    }

    bool delayed;                                   // True if flight is delayed
    cout << "Is the flight delayed? " << flush;     // Prompt the user
    if (!getline(cin, line)) {                      // Get a line of text
        cerr << "Could not read delay response" << endl;
        return false;
    }
    else UpperCase(&line);                          // All answers are UPPER case
    if ('Y' == line.at(0))                          // Yes?
        delayed = true;                             // Set
    else if ('N' == line.at(0))                     // No
        delayed = false;                            // Set
    else {                                          // What??  Neither?
        cerr << "'" << line << "' is neither [Y]es or [N]o" << endl;
        return false;
    }

    FlightRec* fr;                                  // Where to put new flight record
    if (delayed) {                                  // Delayed?
        int eh, em, es;                             // Expected Hours, minutes, seconds
        if (!ParseTime(eh, em, es)) {               // Parse for them
            cerr << "Could not parse expected time" << endl;
            return false;
        }
        fr = new FlightRec(FN, D, h, m, s, FT, eh, em, es); // Delayed signature
    }
    else fr = new FlightRec(FN, D, h, m, s, FT);    // Signature for not delayed

    f->add(*fr);                                    // Finally insert something
    cout << "Added flight: " << fr << endl;
    return true;
}

// Support for command 'e'

bool cancelFlight(List<FlightRec>* f) {
    string line;
    bool r;

    cout << "Enter flight number to delete: " << flush;
    if (!getline(cin, line)) {   // Get a line of text
        cerr << "Could not read flight number" << endl;
        return false;                               // Give it another go
    }
    else UpperCase(&line);                          // All flights are UPPER case

    FlightRec* fr = new FlightRec(line);            // All other fields will be blank or zero
    r = f->remove(*fr);                             // Ditch the flight (if there)
    delete fr;                                      // Ditch the proto record

    if (r) {                                        // Worked??
        cout << "Removed flight: " << line << endl; // Yes!!
        return true;
    }
    else {                                        // Not there
        cerr << "Unknown flight: " << line << endl;
        return false;
    }
}

// Support for command 'f'

bool modifyFlightTime(List<FlightRec>* f) {
    string line;

    cout << "Enter flight number to modify: " << flush;
    if (!getline(cin, line)) {                       // Get a line of text
        cerr << "Could not read flight number" << endl;
        return false;
    }
    else UpperCase(&line);                        // All flights are UPPER case

    FlightRec* fr = new FlightRec(line);
    if (!f->fetch(fr)) {
        cerr << "Unknown flight: " << line << endl;
        delete f;
        return false;
    }
    cout << fr;                                     /* Puts an endl in for us */

    int h, m, s;                                      // Hours, minutes, seconds
    if (!ParseTime(h, m, s)) {
        cerr << "Could not parse flight time" << endl;
        delete f;
        return false;
    }

    if (!f->remove(*fr)) {
        cerr << "Could not remove flight I just found!" << endl;
        delete f;
        return false;                               // ?? We just found it above...
    }

    TimeRec t = TimeRec(h, m, s);                     // Turn numbers into a time record
    cout << "Will modify the ";
    if (fr->getType() == Departure)
        cout << "Departure";
    else cout << "Arrival";
    cout << " of flight ";
    cout << line << " to ";
    cout << t << endl;
    fr->setTime(t);                                 // Update the time!!

    f->add(*fr);                                    // Finally insert updated record
    cout << "Updated flight: " << fr << endl;
    return true;                                    // Won!!
}

// Support for command 'g'

bool delayFlight(List<FlightRec>* f) {
    string line;

    cout << "Enter flight number to delay: " << flush;
    if (!getline(cin, line)) {                       // Get a line of text
        cerr << "Could not read flight number" << endl;
        return false;
    }
    else UpperCase(&line);                          // All flights are UPPER case

    FlightRec* fr = new FlightRec(line);            // Just making a prototype name-only record

    if (!f->fetch(fr)) {
        cerr << "Unknown flight: " << line << endl;
        delete f;
        return false;
    }

    int h, m, s;                                    // Hours, minutes, seconds
    if (!ParseTime(h, m, s)) {
        cerr << "Could not parse delay time" << endl;
        delete f;
        return false;
    }

    if (!f->remove(*fr)) {
        cerr << "Could not remove flight I just found!" << endl;
        delete f;
        return false;                               // We just found it, above!
    }

    TimeRec t = TimeRec(h, m, s);                   // Turn these into a time record
    if (TimeRec(0, 0, 0) == t)                      // Clearing the delay?
        cout << "Clearing the delay for flight " << line << endl;
    else cout << "Delaying flight " << line << " to " << t << endl;

    fr->setDelay(t);                                // Update the delay (or clear it)
    f->add(*fr);                                    // Finally insert updated record
    cout << "Updated flight: " << fr << endl;
    return true;
}

// Support for command 'i'

bool notDeparted(List<FlightRec>* f, TimeRec& TIME) {
    if (TimeRec(0, 0, 0) == TIME) {
        cerr << "Time of day not set" << endl;
        return false;
    }

    const int n = f->length();                      // Get the number of flights
    if (0 == n) {                                   // Anything in there, actually?
        cerr << "No flights entered" << endl;       // Nope, so nothing to do
        return false;
    }

    cout << "Displaying flights that have departed by " << TIME << endl;

    int c = 0;                                      // Count of departed flights
    TimeRec t = TimeRec(0, 0, 0);                   // Used to correctly compare

    for (int i = 0; i < n; i++) {
        FlightRec fr = f->fetchN(i);                // Get flight at slot i
        if (fr.getType() != Departure)              // Not a departure?
            continue;                               // Nope, next flight
        if (fr.getDelay())                          // Delayed?
            t = fr.getExpectedTime();               // Yes, use the EXPECTED time
        else t = fr.getTime();                      // Otherwise, regular time is valid

        if (t < TIME) {                             // Before current time?
            c++;                                    // Yes, so in the past and therefore departed
            cout << fr;                             // Display it
        }
    } // End of for loop

    // Give a properly inflected summary
    if (c == 0) cout << "No flights have departed" << endl;
    else if (c == 1) cout << "One flight has departed" << endl;
    else cout << c << " flights have departed" << endl;

    return true;
}

// Support for command 'j'

bool notArrived(List<FlightRec>* f, TimeRec& TIME) {
    if (TimeRec(0, 0, 0) == TIME) {
        cerr << "Time of day not set" << endl;
        return false;
    }

    const int n = f->length();                      // Get the number of flights
    if (0 == n) {                                   // Anything in there, actually?
        cerr << "No flights entered" << endl;       // Nope, so nothing to do
        return false;
    }

    cout << "Displaying flights that have arrived by " << TIME << endl;

    int c = 0;                                      // Count of departed flights
    TimeRec t = TimeRec(0, 0, 0);                   // Used to correctly compare

    for (int i = 0; i < n; i++) {
        FlightRec fr = f->fetchN(i);                // Get flight at slot i
        if (fr.getType() != Arrival)                // Not an arrival?
            continue;                               // Nope, next flight
        if (fr.getDelay())                          // Delayed?
            t = fr.getExpectedTime();               // Yes, use the EXPECTED time
        else t = fr.getTime();                      // Otherwise, regular time is valid

        if (t < TIME) {                             // Before current time?
            c++;                                    // Yes, so in the past and therefore arrived
            cout << fr;                             // Display it
        }
    } // End of for loop

    // Give a properly inflected summary
    if (c == 0) cout << "No flights have arrived" << endl;
    else if (c == 1) cout << "One flight has arrived" << endl;
    else cout << c << " flights have arrived" << endl;

    return true;
}

// Support for command 'l'

bool sortTime(List<FlightRec>* f) {                 // Implements a bubble sort
    const size_t N = f->length();                   // Find out how much stuff is in there

    if (0 == N) return false;                       // Nothing to sort anyway.
    FlightRec* fr = new FlightRec(f->fetchN(0));    // Get the first element in the list (create a pointer to result)
    if (1 == N) {                                   // A single element is REALLY easy to sort!
        cout << fr;                                 // Display it
        return true;                                // That's that!
    }
#if defined(_WIN64) || (_WIN32)                     // Visual Studio will not allow dynamic array allocation
    FlightRec **fa = new FlightRec*[N];             // A pointer to a list of pointers
#else
    FlightRec* fa[N];                               // An array of pointers to records
#endif

    fa[0] = fr;                                     // Store the pointer in the table (as good a place as any...)
    for (int i = 1; i < N; i++)                     // Step them all out of the list
        fa[i] = new FlightRec(f->fetchN(i));        // They are all in the array of pointers now

    bool swapped = true;                            // True if a pair was swapped
    while (swapped) {                               // Loop until nothing is swapped
        swapped = false;                            // Let's be optimistic and assume nothing got swapped
        for (int i = 1; i < N; i++) {               // And loop through the array
            TimeRec b, a;                           // Before and after times
            if (fa[i - 1]->getDelay())              // Is before delayed?
                b = fa[i - 1]->getExpectedTime();   // Yes, sort on expected time
            else b = fa[i - 1]->getTime();          // Get the time of the 'before' flight record
            if (fa[i]->getDelay())                  // Is after delayed?
                a = fa[i]->getExpectedTime();       // Sort on expected time
            else a = fa[i]->getTime();              // Get the time of the 'after' flight record
            if (b == a) continue;                   // Don't swap equal times!
            if (b < a) continue;                    // If already in order, do nothing
            FlightRec* tr = fa[i - 1];              // Save the pointer to the before
            fa[i - 1] = fa[i];                      // Put after where before was
            fa[i] = tr;                             // Put before where after was
            swapped = true;                         // Mark that we have swapped a pair
            break;                                  // Break out of the for and start all over
        } // End of for loop to look for a pair to swap
    } // End of while loop to determine if anything needed swapping

    for (int i = 0; i < N; i++) cout << fa[i];      // Now print the (sorted) array

#if defined(_WIN64) || (_WIN32)
    delete fa;                                      // Release the memory!
#endif
    return true;
}

// Support for command 'm'

bool displayFlight(List<FlightRec>* f) {
    string line;

    cout << "Enter flight number to display: " << flush;
    if (!getline(cin, line)) {                  // Get a line of text
        cerr << "Could not read flight number" << endl;
        return false;                           // Give it another go
    }
    else UpperCase(&line);                      // All flights are UPPER case

    FlightRec* fr = new FlightRec(line);        // Prototype FlightRec for fetching
    if (f->fetch(fr))                           // Look for it
        cout << fr << endl;
    else cerr << "Unknown flight: " << line << endl;

    delete fr;
    return true;
}
