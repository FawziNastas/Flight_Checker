//
//  main.cpp
//  flights


#include <iostream>
using namespace std;

#include "Global.h"

#include "Global.h"
#include "TimeRec.hpp"
#include "FlightRec.hpp"
#include "Node.hpp"
#include "List.hpp"
#include "Auxiliary.hpp"        // Must be after first two

// #define INITIAL_CHECKOUT /* Uncomment for Internal testing */

int main(int argc, const char* argv[]) {
    List<FlightRec>* flights = new List <FlightRec>();  // Set up an empty list
    TimeRec TIME;                       // Used to do comparisons; defaults to zero

#if defined(INITIAL_CHECKOUT)           // Only if doing check out
#if defined(DEBUG) || defined(_DEBUG)   // Do a little internal checking
#include "CHECKOUT.hpp"
    CHECKOUT();
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
#endif // INITIAL_CHECKOUT)

    /* Be aware that debugging with Xcode will stomp the parser!! */
    char C = '\0';                      // The first character of said string

    while (C != 'X') {                  // Loop until 'X' typed
        cout << endl << "Type a capital X and hit enter to exit, ? for help" << endl;
        cin.get(C);                     // Get a character
        cin.ignore();                   // Flush to EOL
        switch (C) {                    // Go figure out what to do
        case 'a':                   // Allow the user to enter the current time.
            setCurrentTime(TIME);   // Call the auxiliary to handle it
            continue;               // Get another command

        case 'b':                   // Read the flights from a file.
            readFile(flights);      // Call the auxiliary to handle it
            continue;

        case 'c':                   // Write the flights to a file (overwrite input file?)
            writeFile(flights);
            continue;


        case 'd':                   // Allow the user to enter a new flight
            addFlight(flights);
            continue;

        case 'e':                   // Allow the user to delete (cancel) a flight - by entering the FlightNO.
            cancelFlight(flights);
            continue;

        case 'f':                   // Allow the user to modify the Time of a flight by Flight NO.
            modifyFlightTime(flights);
            continue;

        case 'g':                   // Allow the user to enter Delay in a flight by flightNO.
            delayFlight(flights);
            continue;

        case 'h':                   // Display all flights
            cout << "All Flights" << endl;
            cout << flights << endl;
            continue;

        case 'i':                   // Display departure flights that have not departed yet
            notDeparted(flights, TIME);
            continue;

        case 'j':                   // Display arrival flights that have not arrived yet.
            notArrived(flights, TIME);
            continue;

        case 'k':                   // Sort flights by FlightNO.
            cout << "Flights sorted by FlightNO." << endl;
            cout << flights << endl;
            continue;

        case 'l':                   // Sort flights by time
            sortTime(flights);      // Display flights by time
            continue;

        case 'm':                   // Display a particular flight by FlightNO.
            displayFlight(flights);
            continue;

        case 'R':                   // Reset the flight list
            if (0 == flights->length()) {
                cerr << "No flights to clear" << endl;
                continue;
            }

            delete flights;                     // Chuck the list
            flights = new List <FlightRec>();  // Set up an empty list
            cout << "Flight list reset" << endl;
            continue;                           // Start out fresh

        case 'X':                               // Getting out of here?
            break;                              // Exit the loop

        case '?':                               // Display our intuitive command set

            cout << "a\tAllows the user to enter the current time. (00:00) to clear it" << endl;
            cout << "b\tRead the flights from a file." << endl;
            cout << "c\tWrite the flights to a file." << endl;
            cout << "d\tAllow the user to enter a new flight." << endl;
            cout << "e\tAllow the user to delete (cancel) a flight by entering the FlightNO." << endl;
            cout << "f\tAllow the user to modify the Time of a flight." << endl;
            cout << "g\tAllow the user to enter Delay in a flight. (00:00 to cancel delay)" << endl;
            cout << "h\tDisplay all flights." << endl;
            cout << "i\tDisplay departing flights that have not departed yet." << endl;
            cout << "j\tDisplay arriving flights that have not arrived yet." << endl;
            cout << "k\tSort flights by FlightNO." << endl;
            cout << "l\tSort flights by Time." << endl;
            cout << "m\tDisplay a particular flight by FlightNO." << endl;
            cout << "R\tReset the flight list." << endl;
            cout << "?\tDisplay help (this help)." << endl;
            cout << "X\tExit the program." << endl;
            continue;

        default:                    // None of the above??
            cout << "Unknown command character '" << C << "'" << endl;
            cin.ignore();           // Try to get rid of any junk
            continue;               // Complain and try it again
        } // End of Switch
    } // End of While

    return 0;                           // Allow C++ runtime to close out
} // End of main()

