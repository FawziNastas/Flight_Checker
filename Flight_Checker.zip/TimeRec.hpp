//
//  TimeRec.hpp
//  flights


#ifndef TimeRec_hpp
#define TimeRec_hpp

#include "Global.h"

// Note use of inclusion of SOURCE CODE.  Templates appear to
// break without actually seeing code

#if defined(TEMPLATES)
#include "TimeRec.cpp"
#else
#include <iostream>
using namespace std;

class TimeRec {
public:
    
    // Constructors
    TimeRec ();
    TimeRec (const int, const int, const int);
    TimeRec (const int);

    // Arithmetic and assignment operators
    void operator= (const TimeRec &);
    void operator+= (TimeRec);
    const TimeRec operator+ (TimeRec &);
    const TimeRec operator- (TimeRec &);

    // Comparison operators (not exhaustive)
    const bool operator== (TimeRec &);
    const bool operator!= (TimeRec &);
    const bool operator<  (TimeRec &);
    const bool operator>  (TimeRec &);
    
    // Rendering methods
    friend std::ostream& operator<< (std::ostream&, TimeRec);
    friend std::ostream& operator<< (std::ostream&, TimeRec *);

    string toString();
    string toString(TimeRec *);

#if defined(DEBUG) || defined(_DEBUG)   // Only used during development
    static void InternalTest ();
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
};  // End of TimeRec class
#endif // Templates
#endif /* TimeRec_hpp */
