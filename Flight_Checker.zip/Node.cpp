//
//  Node.cpp
//  flights


/** Templated node in a linked list.  It has an entry, which holds whatever we have stored there
    and  a next pointer, which may or may not be end of list */

#include "Global.h"

template <class K> struct Node {
private:
    Node <K> *EOL = (Node <K> *) 0; // Used for initialization and checking
public:
    K entry;
    Node<K> *next;
    
    Node <K> () {                   // Default constructor
        entry = K ();               // Invoke the template's default constructor
        next = EOL;                 // No list of node
    }
};
