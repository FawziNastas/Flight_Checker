//
//  CHECKOUT.hpp
//  flights


#ifndef CHECKOUT_hpp
#define CHECKOUT_hpp

#if defined(DEBUG) || defined(_DEBUG)   // Do a little internal checking
    void CHECKOUT();
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)

#endif /* CHECKOUT_hpp */
