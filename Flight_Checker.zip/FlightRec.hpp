//
//  FlightRec.hpp
//  flights


#ifndef FlightRec_hpp
#define FlightRec_hpp

#include "Global.h"
#if defined (TEMPLATES)
#include "FlightRec.cpp"
#else
#include <iostream>
using namespace std;


class FlightRec {
public:

    // Constructors
    FlightRec ();                   // Gets us a blank flight
    FlightRec (string);             // Used to delete flights
                                    // Delayed flight signature
    FlightRec (const string,const string,const int h, const int, const int,
               const FlightType, const int, const int, const int);
                                    // On time flight constructor signature
    FlightRec (const string,const string,const int, const int, const int,
               const FlightType);

    // Accessors
    const FlightType getType();
    TimeRec getTime();
    const bool getDelay();
    TimeRec getExpectedTime();
    
    // Time Mutators
    void setTime (TimeRec &);
    void setDelay (TimeRec &);

    // Assignment operator
    void operator= (const FlightRec &);
    
    // Flight sorting method; scrubs compare result to a trinary value
    const int flightCompare (const FlightRec &);

    // Various comparison operators we might not use (not exhaustive)
    const bool operator== (const FlightRec &);
    const bool operator!= (const FlightRec &);
    const bool operator<  (const FlightRec &);
    const bool operator>  (const FlightRec &);
    
    // Methods to render the class to a stream
    friend std::ostream& operator<< (std::ostream&, FlightRec);
    friend std::ostream& operator<< (std::ostream&, FlightRec *);

    string toCSV();                     // Used to write a file

#if defined(DEBUG) || defined(_DEBUG)   // Only used during development
    static void InternalTest ();
#endif // DEBUG (Xcode) or D_DEBUG (Visual Studio)
}; // End of FlightRec
#endif //Templates

#endif /* FlightRec_hpp */
